prenom = input("Comment vous appelez-vous ? ")
ville_de_naissance = input("Quelle est votre ville de naissance ? ")
age = input("Quel est votre âge ? ")

print(prenom)
print(ville_de_naissance)
print(age)