b = "10"
b = int(b)