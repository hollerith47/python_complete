a = 5
b = 10
resultat = f"La multiplication de {a} par {b} est égale à {a * b}."
print(resultat)
