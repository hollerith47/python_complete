class Liste(list):
    def __init__(self, nom):
        self.nom = nom

if __name__ == "__main__":
    print("Hello")