"""
Votre script doit afficher les chaînes de caractères suivantes :

Utilisateur 1
Utilisateur 2
Utilisateur 3
Utilisateur 4
Utilisateur 5
Utilisateur 6
Utilisateur 7
Utilisateur 8
Utilisateur 9
Utilisateur 10
"""
