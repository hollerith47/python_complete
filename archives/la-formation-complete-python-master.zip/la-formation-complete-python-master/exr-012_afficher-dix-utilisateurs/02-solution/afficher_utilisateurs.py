# Solution #1
for i in range(10):
    print(f"Utilisateur {i + 1}")

# Solution #2
for i in range(1, 11):
    print(f"Utilisateur {i}")