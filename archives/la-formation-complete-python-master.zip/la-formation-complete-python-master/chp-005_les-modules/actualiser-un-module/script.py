import utils
import importlib
importlib.reload(utils)

print(utils.a)