import random

print(random.a)