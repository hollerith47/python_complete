age = 15
if age >= 18:
    print("Vous êtes majeur")
elif age < 18:
    print("Vous êtes mineur")