# Demander à l'utilisateur d'entrer un premier nombre
# Demander à l'utilisateur d'entrer un deuxième nombre
# Afficher à l'écran le résultat de l'addition (exemple : 'Le résultat de l'addition de 5 + 10 est égal à 15')