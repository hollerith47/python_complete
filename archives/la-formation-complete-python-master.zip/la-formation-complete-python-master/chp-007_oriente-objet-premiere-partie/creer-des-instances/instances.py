class Voiture:
    marque = "Lamborghini"

voiture_01 = Voiture()
voiture_02 = Voiture()
print(voiture_01.marque)
print(voiture_02.marque)
